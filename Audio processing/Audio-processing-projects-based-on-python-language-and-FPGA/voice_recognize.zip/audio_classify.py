import os
import numpy as np
import librosa
import pygame
from sklearn.preprocessing import StandardScaler
from tkinter import Tk, Button, Label

# 播放音频文件
def play_audio(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)

# 提取音频特征
def extract_features(file_path):
    y, sr = librosa.load(file_path)
    mfccs = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13), axis=1)
    chroma = np.mean(librosa.feature.chroma_stft(y=y, sr=sr), axis=1)
    spectral_contrast = np.mean(librosa.feature.spectral_contrast(y=y, sr=sr), axis=1)
    return np.concatenate((mfccs, chroma, spectral_contrast))

# 记录音频特征
def record_features(audio_folder):
    features_dict = {}
    for file_name in os.listdir(audio_folder):
        if file_name.endswith('.flac'):
            file_path = os.path.join(audio_folder, file_name)
            label = os.path.splitext(file_name)[0]
            features_dict[label] = extract_features(file_path)
    return features_dict

# 匹配音频文件并计算相似度
def match_audio(target_features, features_dict):
    min_distance = float('inf')
    matched_file = None
    for label, features in features_dict.items():
        distance = np.linalg.norm(target_features - features)
        if distance < min_distance:
            min_distance = distance
            matched_file = label
    similarity = 1 / (1 + min_distance)  # 计算相似度
    return matched_file, similarity

# 匹配音频
def match_recording():
    target_features = extract_features(recorded_file_path)
    scaler = StandardScaler()
    all_features = np.array(list(features_dict.values()))
    scaler.fit(all_features)
    target_features = scaler.transform([target_features])[0]

    scaled_features_dict = {label: scaler.transform([features])[0] for label, features in features_dict.items()}
    matched_label, similarity = match_audio(target_features, scaled_features_dict)
    label.config(text=f"匹配到的音频文件: {matched_label}.flac\n匹配相似度: {similarity:.4f}")

    matched_file_path = os.path.join(audio_folder, matched_label + '.flac')
    print(f"正在播放匹配到的音频文件: {matched_label}.flac")
    play_audio(matched_file_path)

# 主程序
if __name__ == "__main__":
    audio_folder = 'data'
    recorded_file_path = 'record.flac'

    # 记录所有音频文件的特征
    features_dict = record_features(audio_folder)
    print("音频特征记录完成")

    # 创建GUI
    root = Tk()
    root.title("音频匹配")
    root.geometry("300x200")

    match_button = Button(root, text="匹配音频", command=match_recording)
    match_button.pack(pady=20)

    label = Label(root, text="")
    label.pack(pady=20)

    root.mainloop()
