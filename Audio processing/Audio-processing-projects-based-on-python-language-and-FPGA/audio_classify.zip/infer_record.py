import sounddevice as sd
from scipy.io.wavfile import write

# 设置录音参数
sample_rate = 16000  # 采样率
duration = 5  # 录音持续时间（秒）

print("Recording...")

# 录音
recording = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype='int16')
sd.wait()  # 等待录音结束

# 保存录音为 WAV 文件
write('record.wav', sample_rate, recording)

print("Recording saved as 'record.wav'")
